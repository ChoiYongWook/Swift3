//
//  ViewController.swift
//  CalcDate
//
//  Created by 최 용욱 on 2017. 8. 4..
//  Copyright © 2017년 최 용욱. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var dateInput: UITextField!

    @IBAction func calcDateAction(_ sender: Any) {
        var msg = ""
        let formatter = DateFormatter();
        formatter.dateFormat = "yyyyMMdd"
        
        //입력받은 날짜
        let dateStr = dateInput.text
        
        let calendar = Calendar.current
        let diff = calendar.dateComponents([.day], from: datePicker.date, to: formatter.date(from: dateStr!)!).day
        //let days = calendar.dateComponents([.day], from: startDate!, to: datePicker.date!).day
        
        msg = String((diff! + 1)) + "일 째 입니다."
        
        let alert = UIAlertController(title: "결과", message: msg, preferredStyle: .alert)
        let action = UIAlertAction(title: "확인", style: .default, handler: nil)
        alert.addAction(action)
        show(alert, sender: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

