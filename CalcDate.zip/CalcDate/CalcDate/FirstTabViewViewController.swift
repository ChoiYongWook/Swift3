//
//  FirstTabViewViewController.swift
//  CalcDate
//
//  Created by 최 용욱 on 2017. 8. 4..
//  Copyright © 2017년 최 용욱. All rights reserved.
//

import UIKit

class FirstTabViewViewController: UIViewController {
    
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var dateInput: UITextField!
    @IBAction func calcDateAction(_ sender: Any) {
        var msg = ""
        let formatter = DateFormatter();
        formatter.dateFormat = "yyyy. MM. dd"
        
        //입력받은 날짜 (일 더하기)
        let dateStr = dateInput.text
        
        var dayComponents = DateComponents()
        dayComponents.day = Int(dateStr!)
        
        let calendar = Calendar.current
        let components = calendar.dateComponents([.year, .month, .day], from: datePicker.date)
        let resultDate = calendar.date(byAdding: dayComponents, to: datePicker.date)
        
        msg = formatter.string(from: resultDate!)
        
        let alert = UIAlertController(title: "결과", message: msg, preferredStyle: .alert)
        let action = UIAlertAction(title: "확인", style: .default, handler: nil)
        alert.addAction(action)
        show(alert, sender: nil)
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
