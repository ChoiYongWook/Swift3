//
//  ViewController.swift
//  20170727
//
//  Created by YongWook Choi on 2017. 7. 27..
//  Copyright © 2017년 YongWook Choi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var inputFeild: UITextField!
    
    @IBAction func buttonAction(_ sender: Any) {
        let inputValue = inputFeild.text!
        var convertedValue = 0
        
        if inputFeild.text == ""{
            let msg = "빈값을 입력하셨습니다."
            
            let alert = UIAlertController(title: "결과", message: msg, preferredStyle: .alert)
            
            let action = UIAlertAction(title: "확인", style: .default, handler: nil)
            
            alert.addAction(action)
            
            show(alert, sender: nil)
        }else{
            convertedValue = Int(inputValue)!

            
            let msg = "숫자를 입력하셨습니다."
            let alert = UIAlertController(title: "결과", message: msg, preferredStyle: .alert)
            let action = UIAlertAction(title: "확인", style: .default, handler: nil)
            alert.addAction(action)
            show(alert, sender: nil)
        }
        
        //int를 String으로 변환
//        let msg = "Result is \(sum)"
//        
//        let alert = UIAlertController(title: "결과", message: msg, preferredStyle: .alert)
//        
//        let action = UIAlertAction(title: "확인", style: .default, handler: nil)
//        
//        alert.addAction(action)
//        
//        show(alert, sender: nil)
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

