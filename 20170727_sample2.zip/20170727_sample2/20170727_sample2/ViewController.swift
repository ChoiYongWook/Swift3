//
//  ViewController.swift
//  20170727_sample2
//
//  Created by YongWook Choi on 2017. 7. 27..
//  Copyright © 2017년 YongWook Choi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    //1번 숫자 2번 연산자 3번 결과값
    //버튼 누르면 연산해서 결과 출력
    @IBOutlet weak var valueText1: UITextField!
    @IBOutlet weak var calc: UITextField!
    @IBOutlet weak var valueText2: UITextField!
    
    @IBAction func calcAction(_ sender: Any) {
        let value1 = valueText1.text!
        let value2 = valueText2.text!
        let calcText = calc.text!
        var sum = 0
        var msg = ""
        
        if (value1 != "" || value2 != "" || calcText != ""){
            switch calcText {
            case "+":
                sum = Int(value1)! + Int(value2)!
                msg = String(sum)
                break
            case "-":
                sum = Int(value1)! - Int(value2)!
                msg = String(sum)
                break
            case "*":
                sum = Int(value1)! * Int(value2)!
                msg = String(sum)
                break
            case "/":
                sum = Int(value1)! / Int(value2)!
                msg = String(sum)
                break
            default:
                msg = "사칙연산이 아닙니다."
            }
        }else{
            msg = "빈값을 입력하셨습니다."
        }
        
        let alert = UIAlertController(title: "결과", message: msg, preferredStyle: .alert)
        
        let action = UIAlertAction(title: "확인", style: .default, handler: nil)
        
        alert.addAction(action)
        
        show(alert, sender: nil)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

